const express = require('express');
const router = express.Router();

const { authenticate } = require('../middleware/authenticate ');
const { markLessonCompleted } = require('../controller/progressController');


router.post('/:courseId/lessons/:lessonId/complete', authenticate, markLessonCompleted);

module.exports = router;
