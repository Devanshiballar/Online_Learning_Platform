const express = require('express');
const router = express.Router();
const { IsAdmin, authenticate } = require('../middleware/authenticate ');
const { createCourse, updateCourse, deleteCourse, getAllCourses, getCourseById } = require('../controller/courseController');

// Admin-only routes
router.post('/', authenticate,IsAdmin, createCourse);
router.put('/:id',authenticate,IsAdmin , updateCourse);
router.delete('/:id',authenticate,IsAdmin , deleteCourse);

// Public routes
router.get('/', getAllCourses);
router.get('/:id', getCourseById);

module.exports = router;
