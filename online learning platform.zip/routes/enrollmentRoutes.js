const express = require('express');
const { authenticate } = require('../middleware/authenticate ');
const { enrollInCourse } = require('../controller/enrollmentController');
const router = express.Router();

router.post('/:courseId', authenticate, enrollInCourse);

module.exports = router;
