// const Enrollment = require('../models/enrollmentModel');

// exports.trackProgress = async (req, res) => {
//     try {
//         const enrollment = await Enrollment.findOne({ user: req.user._id, course: req.params.courseId });
//         if (!enrollment) return res.status(404).json({ success: false, message: 'Enrollment not found' });
//         enrollment.completedLessons.push(req.params.lessonId);
//         await enrollment.save();
//         res.status(200).json({ success: true, data: enrollment });
//     } catch (error) {
//         res.status(400).json({ success: false, error });
//     }
// };
const Progress = require('../models/progressModel');

exports.markLessonCompleted = async (req, res) => {
    let progress = await Progress.findOne({ userId: req.user._id, courseId: req.params.courseId });
    if (!progress) {
        progress = new Progress({
            userId: req.user._id,
            courseId: req.params.courseId,
            completedLessons: []
        });
    }
    
    if (progress.completedLessons.includes(req.params.lessonId)) {
        return res.status(400).send('Lesson already completed.');
    }

    progress.completedLessons.push(req.params.lessonId);
    await progress.save();
    
    res.send('Lesson marked as completed.');
};
