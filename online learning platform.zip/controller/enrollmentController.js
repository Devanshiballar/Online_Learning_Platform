const User = require('../models/userModel');
const Course = require('../models/courseModel');

exports.enroll = async (req, res) => {
    const course = await Course.findById(req.params.courseId);
    if (!course) return res.status(404).send('Course not found.');

    const user = await User.findById(req.user._id);
    if (user.enrolledCourses.includes(course._id)) return res.status(400).send('Already enrolled.');

    user.enrolledCourses.push(course._id);
    await user.save();
    
    res.send('Enrolled successfully.');
};
