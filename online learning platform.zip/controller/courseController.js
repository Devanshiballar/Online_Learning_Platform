const Course = require('../models/courseModel');

// Create a new course (Admin only)
exports.createCourse = async (req, res) => {
    try {
        const course = await Course.create({ ...req.body, createdBy: req.user._id });
        res.status(201).json({ success: true, message: 'Course created successfully', data: course });
    } catch (error) {
        res.status(400).json({ success: false, message: 'Failed to create course', error: error.message });
    }
};

// Get all courses
exports.getAllCourses = async (req, res) => {
    try {
        const courses = await Course.find().populate('lessons');
        res.status(200).json({ success: true, message: 'Courses retrieved successfully', data: courses });
    } catch (error) {
        res.status(400).json({ success: false, message: 'Failed to retrieve courses', error: error.message });
    }
};

// Get a single course by ID
exports.getCourseById = async (req, res) => {
    try {
        const course = await Course.findById(req.params.id).populate('lessons');
        if (!course) {
            return res.status(404).json({ success: false, message: 'Course not found' });
        }
        res.status(200).json({ success: true, message: 'Course retrieved successfully', data: course });
    } catch (error) {
        res.status(400).json({ success: false, message: 'Failed to retrieve course', error: error.message });
    }
};

// Update a course (Admin only)
exports.updateCourse = async (req, res) => {
    try {
        const course = await Course.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!course) {
            return res.status(404).json({ success: false, message: 'Course not found' });
        }
        res.status(200).json({ success: true, message: 'Course updated successfully', data: course });
    } catch (error) {
        res.status(400).json({ success: false, message: 'Failed to update course', error: error.message });
    }
};

// Delete a course (Admin only)
exports.deleteCourse = async (req, res) => {
    try {
        const course = await Course.findByIdAndDelete(req.params.id);
        if (!course) {
            return res.status(404).json({ success: false, message: 'Course not found' });
        }
        res.status(200).json({ success: true, message: 'Course deleted successfully' });
    } catch (error) {
        res.status(400).json({ success: false, message: 'Failed to delete course', error: error.message });
    }
};
